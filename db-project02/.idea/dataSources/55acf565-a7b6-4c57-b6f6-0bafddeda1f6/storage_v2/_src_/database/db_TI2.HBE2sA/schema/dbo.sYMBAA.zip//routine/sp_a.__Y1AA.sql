CREATE PROCEDURE sp_a @CC NVARCHAR(12)
AS
BEGIN
SELECT FullName, CONCAT(StressAddress, ', ', Zipcode) FROM Customer
WHERE CC = @CC
END
go

